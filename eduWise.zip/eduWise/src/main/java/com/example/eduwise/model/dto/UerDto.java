package com.example.eduwise.model.dto;

public class UerDto {
}
