package com.example.eduwise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EduWiseApplication {

    public static void main(String[] args) {
        SpringApplication.run(EduWiseApplication.class, args);
    }

}
