package com.example.eduwise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EduWiseApplicationTests {

    @Test
    void contextLoads() {
    }

}
